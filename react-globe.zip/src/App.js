// src/App.js
import React from "react";
import World from "./World";

function App() {
  return (
    <div className="App">
      <World />
    </div>
  );
}

export default App;
